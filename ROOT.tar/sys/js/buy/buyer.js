$(init)

function init() {
  // setInterval(updateBuyMoney, REFRESH_TIME )
}
