$(init)

function init() {
  // promise('GET','/buyer/buyer_balance',null, (e)=>{
  //   $('#u-money').text(e.balance+e.servicefee)
  // }, null)
}
