var _id;

$(init);

function init() {
  _id = getUrlParam('id')


  initList();
  $('body').on('click', '.choose-task', doChoose);
  $('body').on('click', '.return', doReturn);
}

async function initList() {
  param = { taskkeyid: _id }
  ret = await promiseCall( [URL_BUY_TASKDETAIL, encodeQuery(param)].join('?'), null )
  Object.assign(ret.data, { show:true,imgPrefix: IMG_PREFIX });
  $('.g-detail').append(await renderTmpl(TMPL_BUY_ORDER_DETAIL, ret.data, rdHelper))
  $(".fancybox").fancybox({'titlePosition':'inside','type':'image'});
}


function doChoose(e) {
  var obj = {
    taskkeyId: _id
  }
  promise('GET',[URL_BUYER_GET_TASK, encodeQuery(obj)].join('?') ,null, cbChoose, null)
} 


function cbChoose(e) {
  msgbox(MSG_ACCEPT_TASK_SUCC,MSG_GOON_ACCEPT,MSG_LOOKUP_TASK,gotoPage)
}

function gotoPage(result) {
  if (result) {
    location.href = 'chooseTask.html'
  }else{
    location.href = 'listOrder.html'
  }
}

function doReturn() {
  location.href = 'chooseTask.html'
}