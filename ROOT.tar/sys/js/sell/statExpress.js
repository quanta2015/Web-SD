var _id;
var _shop = {};
let pageData;

$(init);

function init() {
  pageData =  Object.assign({}, PAGE_DATA);

  initTime();
  initList(pageData);

  $('#searchBtn').on('click', doSearch);
  $('#exportBtn').on('click', doExport);
  $('#batchExpressBtn').on('change', doBatchExpress);
}

function doBatchExpress(e) {
  var files = e.target.files === undefined ? (e.target && e.target.value ? [{ name: e.target.value.replace(/^.+\\/, '')}] : []) : e.target.files
  if (files.length === 0) return;
  // promiseUpload('/task/batch_sendexpress',files[0], cbBatchExpress)

  
  // var xhr = new XMLHttpRequest();
  // xhr.onreadystatechange = function(e) {
  //     if ( 4 == this.readyState ) {
  //         console.log(['xhr upload complete', e]);
  //     }
  // };


  // xhr.onload = function () {
  //     if (this.status === 200) {
  //         var filename = "";
  //         var disposition = xhr.getResponseHeader('Content-Disposition');
  //         if (disposition && disposition.indexOf('attachment') !== -1) {
  //             var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
  //             var matches = filenameRegex.exec(disposition);
  //             if (matches != null && matches[1]) filename = matches[1].replace(/['"]/g, '');
  //         }
  //         var type = xhr.getResponseHeader('Content-Type');

  //         var blob = typeof File === 'function'
  //             ? new File([this.response], filename, { type: type })
  //             : new Blob([this.response], { type: type });
  //         if (typeof window.navigator.msSaveBlob !== 'undefined') {
  //             // IE workaround for "HTML7007: One or more blob URLs were revoked by closing the blob for which they were created. These URLs will no longer resolve as the data backing the URL has been freed."
  //             window.navigator.msSaveBlob(blob, filename);
  //         } else {
  //             var URL = window.URL || window.webkitURL;
  //             var downloadUrl = URL.createObjectURL(blob);

  //             if (filename) {
  //                 // use HTML5 a[download] attribute to specify filename
  //                 var a = document.createElement("a");
  //                 // safari doesn't support this yet
  //                 if (typeof a.download === 'undefined') {
  //                     window.location = downloadUrl;
  //                 } else {
  //                     a.href = downloadUrl;
  //                     a.download = filename;
  //                     document.body.appendChild(a);
  //                     a.click();
  //                 }
  //             } else {
  //                 window.location = downloadUrl;
  //             }

  //             setTimeout(function () { URL.revokeObjectURL(downloadUrl); }, 100); // cleanup
  //         }
  //     }
  // };

  // xhr.open('post', '/task/batch_sendexpress', true);
  // xhr.setRequestHeader("Content-Type","multipart/form-data");
  // xhr.send(formData);



  var fd = new FormData();
  fd.append("file", files[0]);

  var xhr = new XMLHttpRequest();
  xhr.open('POST', '/task/batch_sendexpress', true);
  
  xhr.upload.onprogress = function(e) {
    if (e.lengthComputable) {
      var percentComplete = (e.loaded / e.total) * 100;
      console.log(percentComplete + '% uploaded');
    }
  };
  xhr.onload = function () {
      if (this.status === 200) {
          var filename = "";
          var disposition = xhr.getResponseHeader('Content-Disposition');
          if (disposition && disposition.indexOf('attachment') !== -1) {
              var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
              var matches = filenameRegex.exec(disposition);
              if (matches != null && matches[1]) filename = matches[1].replace(/['"]/g, '');
          }
          var type = xhr.getResponseHeader('Content-Type');

          var blob = typeof File === 'function'
              ? new File([this.response], filename, { type: type })
              : new Blob([this.response], { type: type });
          if (typeof window.navigator.msSaveBlob !== 'undefined') {
              // IE workaround for "HTML7007: One or more blob URLs were revoked by closing the blob for which they were created. These URLs will no longer resolve as the data backing the URL has been freed."
              window.navigator.msSaveBlob(blob, filename);
          } else {
              var URL = window.URL || window.webkitURL;
              var downloadUrl = URL.createObjectURL(blob);

              if (filename) {
                  // use HTML5 a[download] attribute to specify filename
                  var a = document.createElement("a");
                  // safari doesn't support this yet
                  if (typeof a.download === 'undefined') {
                      window.location = downloadUrl;
                  } else {
                      a.href = downloadUrl;
                      a.download = filename;
                      document.body.appendChild(a);
                      a.click();
                  }
              } else {
                  window.location = downloadUrl;
              }

              setTimeout(function () { URL.revokeObjectURL(downloadUrl); }, 100); // cleanup
          }
      }
  };
  xhr.send(fd);
}


function cbBatchExpress() {
  notifyInfo('上传成功！')
}


function doExport() {
  let cdt = {
    fromDate: $("#from").val() + ':00',
    toDate: $("#to").val()+ ':00'
  }
  window.location.href =HOST +  ['/task/export_express', encodeQuery(cdt)].join('?');
}

function doSearch() {
  initList(pageData)
}

function initTime() {
  let from =  moment().subtract('days',7).format('YYYY-MM-DD') + ' 00:00';
  let to = moment().format('YYYY-MM-DD') + ' 23:59'
  $("#from").datetimepicker({ value: from, format:'Y-m-d H:i'});
  $("#to").datetimepicker({value: to, format:'Y-m-d H:i'});
}

function initList(pg) {
  let cdt = {
    fromDate: $("#from").val() + ':00',
    toDate: $("#to").val()+ ':00'
  }
  Object.assign( cdt, pg);
  promiseTmpl('GET', '/tmpl/sell/list_stat_express.tmpl', ['/task/get_express_used', encodeQuery(cdt)].join('?'), null, cbListTask)
}


function cbListTask(r,ret) {
  Object.assign(ret, pageData);
  ret.type = 'buy';
  totalPages = Math.ceil(ret.total/PAGE_DATA.pageSize);
  $(".portlet-body table").remove();
  $(".portlet-body").prepend($.templates(r).render(ret, rdHelper));
  if ($('.table-pg').text() == '') initPage(totalPages);
}

function initPage(totalPages) {
  $('.portlet-body .table-pg').twbsPagination({
    totalPages: totalPages || 1,
    onPageClick: function(event, page) {
      pageData.pageIndex = page - 1;
      initList(pageData);
    }
  })
}
