$(init);

function init() {
  // setInterval(updateSellMoney, REFRESH_TIME )
}